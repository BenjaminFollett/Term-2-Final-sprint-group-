const ProductChecker = () => {
  return <div>Antique couch</div>;
};

export default ProductChecker;
