//This is the function to help add data to the local host from just a click of a button.

import React from "react";

const AddToCart = ({ item }) => {
  const handleAddToCart = async () => {
    const response = await fetch("http://localhost:5000/cart", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(item),
    });
    if (response.ok) {
      console.log("Product added to cart");
    } else {
      console.error("Failed to add product to cart");
    }
  };

  return <button onClick={handleAddToCart}>Add to Cart</button>;
};

export default AddToCart;
