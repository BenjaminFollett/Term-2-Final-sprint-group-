import { render, screen } from "@testing-library/react";
import Stock from "./StockChecker"; // Ensure the import path is correct

test("two-kettles-in-stock", () => {
  render(<Stock />);
  const textElement = screen.getByText("Two Kettles in Stock");
  expect(textElement).toBeInTheDocument();
});
