//Benjamin Follett, Alex Condon-Escott, Francisco Castillo
//Final Sprint Group Project
//Start Date: April 1st, 2024
//End Date: April 14th, 2024

//Contributions:
//Benjamin Follett (Product List page and Product details page) & 1 unit test.
//Alex Condon-Escott (Shoppping cart page) & 1 unit test.
//Francisco Castillo (Check out page)& 1 unit test.

//imports to makepage display.

import "./App.css";
import Navigation from "./components/Navigation";
import Body from "./components/Body";
import ProductDetails1 from "./components/ProductDetails1";
import ProductDetails2 from "./components/ProductDetails2";
import ProductDetails3 from "./components/ProductDetails3";
import ProductDetails4 from "./components/ProductDetails4";
import ProductDetails5 from "./components/ProductDetails5";
import ProductDetails6 from "./components/ProductDetails6";
import ShoppingCart from "./components/ShoppingCart";
import CheckOut from "./components/CheckOut";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";

function App() {
  let [items, setItems] = useState([]);
  let [cart, setCart] = useState([]);

  function addtocart(id) {
    setCart([...cart, id]);
    console.log(cart);
  }

  useEffect(() => {
    const fetchItems = async () => {
      const response = await fetch("http://localhost:5000/items");
      const data = await response.json();
      setItems(data);
    };

    fetchItems();
  }, []);

  return (
    <Router>
      <div className="App">
        <Navigation />
        <Routes>
          <Route path="/" element={<Body items={items} />} />
          {items.map((item) => {
            const ProductDetailComponent = [
              ProductDetails1,
              ProductDetails2,
              ProductDetails3,
              ProductDetails4,
              ProductDetails5,
              ProductDetails6,
            ][item.id - 1];
            return (
              <Route
                key={item.id}
                path={`/ProductDetails${item.id}`}
                element={<ProductDetailComponent item={item} add={addtocart} />}
              />
            );
          })}
          <Route path="/ShoppingCart" element={<ShoppingCart cart={cart} />} />
          <Route path="/CheckOut" element={<CheckOut checkout={cart} />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
