import ProductChecker from "./ProductChecker";
import { render, screen } from "@testing-library/react";

test("Product in stock", () => {
    render(<ProductChecker/>);
    const textElement = screen.getByText("Antique couch");
    expect(textElement).toBeInTheDocument();
});