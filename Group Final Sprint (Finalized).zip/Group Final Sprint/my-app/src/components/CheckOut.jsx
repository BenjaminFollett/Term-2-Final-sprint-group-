import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
const CheckOut = () => {
  const [cart, setCart] = useState([]);
  const [subtotal, setSubtotal] = useState(0);
  const [tax, setTax] = useState(0);
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const fetchCart = async () => {
      try {
        const response = await fetch("http://localhost:5000/cart");
        if (response.ok) {
          const data = await response.json();
          setCart(data);
        } else {
          console.error("Failed to obtain cart");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
    fetchCart();
  }, []); //

  useEffect(() => {
    // Calculate subtotal
    const subtotalValue = cart.reduce(
      (acc, item) => acc + parseFloat(item.price.replace("$", "")),
      0
    );
    setSubtotal(subtotalValue);

    // Calculate tax
    const taxRate = 0.15; // 15%
    const taxValue = subtotalValue * taxRate;
    setTax(taxValue);

    // Calculate total
    const totalValue = subtotalValue + taxValue;
    setTotal(totalValue);
  }, [cart]);

  return (
    <div>
      <main>
        <section className="account-details">
          {/* Account - Shipping - Payment section */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginBottom: "20px",
            }}
          >
            {/* Account */}
            <div style={{ marginRight: "20px" }}>Account</div>
            <svg width="50" height="50">
              <line
                x1="0"
                y1="25"
                x2="50"
                y2="25"
                stroke="black"
                strokeWidth="2"
              />
            </svg>
            <svg width="50" height="50">
              {/* Here we can make a circle. Also we can create other figures. */}
              <circle cx="20" cy="25" r="10" fill="black" />

              {/* This is the checkmark - here we can change size, color and width */}
              <path
                d="M10 25 l5 5 l10 -10"
                stroke="white"
                strokeWidth="2"
                fill="none"
              />
            </svg>
            <svg width="50" height="50">
              <line
                x1="050"
                y1="25"
                x2="0"
                y2="25"
                stroke="black"
                strokeWidth="2"
              />
            </svg>
            &nbsp;&nbsp;&nbsp;
            {/* Shipping */}
            <div style={{ marginRight: "20px" }}>Shipping</div>
            <svg width="50" height="50">
              <line
                x1="0"
                y1="25"
                x2="50"
                y2="25"
                stroke="black"
                strokeWidth="2"
              />
            </svg>
            <svg width="50" height="50">
              {/* Here we can make a circle. Also we can create other figures. */}
              <circle cx="20" cy="25" r="10" fill="black" />

              {/* This is the checkmark - here we can change size, color and width */}
              <path
                d="M10 25 l5 5 l10 -10"
                stroke="white"
                strokeWidth="2"
                fill="none"
              />
            </svg>
            <svg width="50" height="50">
              <line
                x1="60"
                y1="25"
                x2="0"
                y2="25"
                stroke="black"
                strokeWidth="2"
              />
            </svg>
            &nbsp;&nbsp;&nbsp;
            {/* Payment */}
            <div>Payment</div>
          </div>

          <h2>Account Details</h2>
          <form>
            <label
              htmlFor="email"
              style={{ display: "block", marginBottom: "10px" }}
            >
              Email address:
            </label>
            <input
              className="label-style"
              type="email"
              id="email"
              name="email"
            />
            <br />
            <label
              htmlFor="password"
              style={{
                display: "block",
                marginTop: "10px",
                marginBottom: "10px",
              }}
            >
              Password:
            </label>
            <input
              className="label-style"
              type="password"
              id="password"
              name="password"
            />
            <br />
            <br />

            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <button
                type="submit"
                style={{ marginTop: "12px", marginLeft: "150px" }}
                className="register"
              >
                Register for account
              </button>
              <button
                type="submit"
                style={{ marginBottom: "10px", marginRight: "80px" }}
                className="login"
              >
                Login
              </button>
            </div>
            <br />
            <hr style={{ width: "80%", margin: "auto" }} />
            {/*this the line between buttons*/}
            <br />
            <div style={{ display: "flex", justifyContent: "space-between" }}>
              <button
                type="submit"
                style={{ marginTop: "12px", marginLeft: "150px" }}
                className="cancel-order"
              >
                Cancel Order
              </button>
              <Link to="/">
                <button
                  type="submit"
                  style={{ marginBottom: "10px", marginRight: "80px" }}
                  className="continue-shopping"
                >
                  Continue Shopping
                </button>
              </Link>
            </div>
          </form>
        </section>

        <section className="order-summary">
          <h2>Order Summary</h2>
          {(item, index) => (
            <div className="item-details" key={index}>
              <img
                src={item.image}
                alt={item.name}
                width="35px"
                height="45px"
              />
              <div className="item-name-price">
                <span className="item-name"> {item.name}</span>
                <span className="item-price">${item.price}</span>
              </div>
            </div>
          )}
          {/*Here is located the Apply button and blank label*/}
          <label
            className="gift-discount"
            style={{ display: "block", marginBottom: "15px" }}
          >
            Gift Card / Discount code
          </label>
          <input
            className="label-style-apply"
            type="text"
            id="apply"
            name="apply"
          />
          <button
            type="submit"
            style={{ marginRight: "5px" }}
            className="apply"
          >
            Apply
          </button>
          {/*Price Data*/}
          <div className="total">
            <label
              htmlFor="subtotal"
              style={{
                display: "flex",
                alignItems: "baseline",
                marginTop: "10px",
              }}
            >
              Sub Total
            </label>
            <label
              style={{
                marginLeft: "515px",
                display: "flex",
                alignItems: "baseline",
              }}
            >
              ${subtotal.toFixed(2)}
            </label>
            <label
              htmlFor="tax"
              style={{
                display: "flex",
                alignItems: "baseline",
                marginTop: "10px",
              }}
            >
              Tax
            </label>
            <label
              style={{
                marginLeft: "515px",
                display: "flex",
                alignItems: "baseline",
              }}
            >
              ${tax.toFixed(2)}
            </label>
            <label
              htmlFor="shipping"
              style={{
                display: "flex",
                alignItems: "baseline",
                marginTop: "10px",
              }}
            >
              Shipping
            </label>
            <label
              style={{
                marginLeft: "515px",
                display: "flex",
                alignItems: "baseline",
                color: "green",
              }}
            >
              Free
            </label>
            <label
              htmlFor="total"
              style={{
                display: "flex",
                alignItems: "baseline",
                marginTop: "10px",
              }}
            >
              Total
            </label>
            <label
              style={{
                marginLeft: "515px",
                display: "flex",
                alignItems: "baseline",
              }}
            >
              ${total.toFixed(2)}
            </label>
          </div>
        </section>
      </main>
    </div>
  );
};

export default CheckOut;
