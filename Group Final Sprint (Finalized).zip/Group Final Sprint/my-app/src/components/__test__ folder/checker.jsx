const checker = () => {
  return (
    <div>
      <div>Order Summary</div>
    </div>
  );
};

export default checker;
