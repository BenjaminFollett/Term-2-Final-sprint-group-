//This is the Shopping cart section this is used for receiving the data that the user wants and displaying it.

import { Link } from "react-router-dom";
import React, { useState, useEffect } from "react";

function ShoppingCart() {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    const fetchCart = async () => {
      const response = await fetch("http://localhost:5000/cart");
      if (response.ok) {
        const data = await response.json();
        setCart(data);
      } else {
        console.error("Failed to obtain cart");
      }
    };
    fetchCart();
  }, [cart]);

  const deleteCart = async (id) => {
    await fetch(`http://localhost:5000/cart/${id}`, {
      method: "DELETE",
    });
    console.log(id);

    setCart(cart.filter((item) => item.id !== id));
  };

  const updateQuantity = (id, newQuantity) => {
    setCart(
      cart.map((item) => {
        if (item.id === id) {
          return { ...item, quantity: newQuantity };
        }
        return item;
      })
    );
  };

  return (
    <div>
      <h2>Shopping Cart</h2>
      <br />
      <hr />
      {cart.map((item) => (
        <div key={item.id}>
          {item.name} - {item.price} {item.quantity}
          <button onClick={() => deleteCart(item.id)}>Delete</button>
          <hr />
          <br />
        </div>
      ))}
      <Link to="/CheckOut">
        <button
          onClick={() => console.log("Proceeding to checkout")}
          style={{
            marginTop: "20px",
            padding: "10px 20px",
            backgroundColor: "blue",
            color: "white",
            fontSize: "16px",
            border: "none",
            borderRadius: "5px",
            cursor: "pointer",
          }}
        >
          Proceed to Checkout
        </button>
      </Link>
    </div>
  );
}

export default ShoppingCart;
