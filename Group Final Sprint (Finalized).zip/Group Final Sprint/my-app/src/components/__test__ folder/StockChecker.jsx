const Stock = () => {
  return (
    <div>
      <div>Two Kettles in Stock</div>
    </div>
  );
};

export default Stock;
