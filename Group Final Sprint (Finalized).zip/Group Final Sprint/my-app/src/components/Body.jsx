//Body semantic tag.

import { Link } from "react-router-dom";
import AddToCart from "./Addtocart";
import { useState, useEffect } from "react";

//function Body() {
const Body = () => {
  const [items, setItems] = useState([]);
  const ImageComponent = ({ imagePath }) => {
    let src;
    try {
      src = require(`../images/${imagePath}`);
    } catch (e) {
      console.error("Could not load image at ${imagePath}:", e);

      src = require("../images/kettle.jpg");
    }

    return <img src={src} alt="Description" width="250px" height="175px" />;
  };
  useEffect(() => {
    const fetchItems = async () => {
      const response = await fetch("http://localhost:5000/items");
      if (response.ok) {
        const data = await response.json();
        setItems(data);
      } else {
        console.error("Failed to fetch items");
      }
    };
    fetchItems();
  }, []);
  return (
    <div>
      {items.map((item) => (
        <Link
          to={`/ProductDetails${item.id}`}
          key={item.id}
          style={{ textDecoration: "none", color: "inherit" }}
        >
          <div className="box">
            <div key={item.id}>
              <div className="inner-box">
                <h6>{item.name}</h6>
              </div>
              <div className="inner-box2">
                <h5>{item.price}</h5>
              </div>
              <ImageComponent imagePath={item.image.split("/").pop()} />
              <AddToCart item={item} />
            </div>
          </div>
        </Link>
      ))}
    </div>
  );
};
//   return (
//     <body>
//       <Link to="ProductDetails1">
//         <div class="box">
//           <img src="Antique couch.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Antique couch</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $1299.99</h5>
//           </div>
//         </div>
//       </Link>
//       <Link to="ProductDetails2">
//         <div class="box">
//           <img src="kettle.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Kettle</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $29.99</h5>
//           </div>
//         </div>
//       </Link>
//       <Link to="ProductDetails3">
//         <div class="box">
//           <img src="lamp.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Lamp</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $39.99</h5>
//           </div>
//         </div>
//       </Link>
//       <Link to="ProductDetails4">
//         <div class="box">
//           <img src="stool.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Stool</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $89.99</h5>
//           </div>
//         </div>
//       </Link>
//       <Link to="ProductDetails5">
//         <div class="box">
//           <img src="toaster.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Toaster</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $19.99</h5>
//           </div>
//         </div>
//       </Link>
//       <Link to="ProductDetails6">
//         <div class="box">
//           <img src="table set.jpg" width="250px" height="175px" />
//           <div class="inner-box">
//             <h5>Table set</h5>
//           </div>
//           <div class="inner-box2">
//             <h5>CDN $299.99</h5>
//           </div>
//         </div>
//       </Link>
//     </body>
//   );
// }

export default Body;
