import { render, screen } from "@testing-library/react";
import Tester from "./checker";

test("order-summary", () => {
  render(<Tester />);
  const textElement = screen.getByText("Order Summary");
  expect(textElement).toBeInTheDocument();
});
